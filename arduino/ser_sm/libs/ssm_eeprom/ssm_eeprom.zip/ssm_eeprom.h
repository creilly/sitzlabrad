#ifndef SSM_EEPROM_H
#define SSM_EEPROM_H

#include "Arduino.h"

byte read_id();
void write_id(byte id);

#endif
